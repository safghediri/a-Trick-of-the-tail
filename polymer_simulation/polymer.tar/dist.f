      program rg_ree
      implicit real*8(a-h,o-z)
      character*8 note
      
      ! n = max atoms, nt = max frames
      parameter (n=1000, nt=1000000)
      parameter (n_finestra = 100) 
      
      dimension x(n),y(n),z(n)
      dimension rg_history(n_finestra)
      
      real*8 sum_rg, sum_rg2, media_cum_rg, var_cum_rg
      real*8 sum_mob, sum_mob2, media_mob, var_mob, devst_mob
      real*8 sum_ree, sum_ree2, media_cum_ree, var_cum_ree
      integer n_frames, idx_mob, n_prot
      
      ! Initializazion
      sum_rg   = 0.d0
      sum_rg2  = 0.d0
      sum_ree  = 0.d0
      sum_ree2 = 0.d0
      n_frames = 0
      idx_mob  = 0
      do i=1,n_finestra
         rg_history(i) = 0.d0
      end do

      open(unit=10,file='./46/HISTORY',status='old')
      open(unit=11,file='protein_dynamics_trajectory.dat',
     &     status='unknown')
      
      write(11,'(a10,a12,a15,a15,a15,a15)') '# Time', 'Rg', 
     &      'Var_Cum_Rg', 'Var_Mob_Rg', 'Ree', 'Var_Cum_Ree'

      read (10,*) 
      read (10,*) k, k, nn 
      
      if (nn.gt.n) then
         print*, "Error: nn larger than n!"
         stop
      end if

      ! Exclude last 2 particles (UDG+Nsome)
      n_prot = nn - 2

      do it=1,nt
         read (10,'(a8,i10)',end=99) note,itime
         read (10,*) 
         read (10,*) 
         read (10,*) 
         
         do iat=1,nn
            read (10,*) 
            read (10,*) x(iat),y(iat),z(iat)
         end do

         ! 1. Unwrapping PBC on polymer chain
         do iat=2,n_prot
            dx = x(iat) - x(iat-1)
            if (dx .gt.  40.d0) x(iat) = x(iat) - 80.d0
            if (dx .lt. -40.d0) x(iat) = x(iat) + 80.d0
            dy = y(iat) - y(iat-1)
            if (dy .gt.  40.d0) y(iat) = y(iat) - 80.d0
            if (dy .lt. -40.d0) y(iat) = y(iat) + 80.d0
            dz = z(iat) - z(iat-1)
            if (dz .gt.  70.d0) z(iat) = z(iat) - 140.d0
            if (dz .lt. -70.d0) z(iat) = z(iat) + 140.d0
         end do

         ! 2. Compute End-to-End Distance (Ree) between monomers 1-n_prot
         dx_ee = x(n_prot) - x(1)
         dy_ee = y(n_prot) - y(1)
         dz_ee = z(n_prot) - z(1)
         ree = dsqrt(dx_ee*dx_ee + dy_ee*dy_ee + dz_ee*dz_ee)

         ! 3. Compute center-of-mass
         xc=0.d0 ; yc=0.d0 ; zc=0.d0
         do iat=1,n_prot
            xc = xc + x(iat)
            yc = yc + y(iat)
            zc = zc + z(iat)
         end do
         xc = xc / dfloat(n_prot)
         yc = yc / dfloat(n_prot)
         zc = zc / dfloat(n_prot)

         ! 4. Compute R_g
         gyra=0.d0
         do k=1,n_prot
            dx = x(k) - xc
            dy = y(k) - yc
            dz = z(k) - zc
            gyra = gyra + (dx*dx + dy*dy + dz*dz)
         end do
         rg = dsqrt(gyra / dfloat(n_prot))
         
         n_frames = n_frames + 1
         
         ! --- 5. CUMULATIVE STATISTICS for Rg
         sum_rg  = sum_rg + rg
         sum_rg2 = sum_rg2 + (rg*rg)
         
         var_cum_rg = 0.d0
         if (n_frames .gt. 1) then
            media_cum_rg = sum_rg / dfloat(n_frames)
            var_cum_rg   = (sum_rg2 / dfloat(n_frames)) - 
     &                     (media_cum_rg * media_cum_rg)
            if (var_cum_rg .lt. 0.d0) var_cum_rg = 0.d0
         end if

         ! --- 6. CUMULATIVE STATISTICS for R_ee
         sum_ree  = sum_ree + ree
         sum_ree2 = sum_ree2 + (ree*ree)
         
         var_cum_ree = 0.d0
         if (n_frames .gt. 1) then
            media_cum_ree = sum_ree / dfloat(n_frames)
            var_cum_ree   = (sum_ree2 / dfloat(n_frames)) - 
     &                     (media_cum_ree * media_cum_ree)
            if (var_cum_ree .lt. 0.d0) var_cum_ree = 0.d0
         end if

         ! --- 7. MOBILE WINDOW STATISTICS for Rg
         idx_mob = mod(n_frames - 1, n_finestra) + 1
         rg_history(idx_mob) = rg
         
         var_mob   = 0.d0
         devst_mob = 0.d0
         if (n_frames .ge. n_finestra) then
            sum_mob  = 0.d0
            sum_mob2 = 0.d0
            do i=1,n_finestra
               sum_mob  = sum_mob + rg_history(i)
               sum_mob2 = sum_mob2 + (rg_history(i)*rg_history(i))
            end do
            media_mob = sum_mob / dfloat(n_finestra)
            var_mob   = (sum_mob2 / dfloat(n_finestra)) - 
     &                  (media_mob * media_mob)
            if (var_mob .lt. 0.d0) var_mob = 0.d0
            devst_mob = dsqrt(var_mob)
         end if

         write(11,'(i10,f12.4,e15.6,e15.6,f15.4,e15.6)') 
     &         itime, rg, var_cum_rg, var_mob, ree, var_cum_ree

      end do

 99   continue
      close(10)
      close(11)
      print*, "Output saved in protein_dynamics_trajectory.dat"
      stop
      end

